package com.employeeskills.Model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Table(name="employee1")
@Getter
@Setter
public class Employee {

    @Id
    @Column(name="employeeno")
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int employeeID;

    @Column(name="employeename")
    private String empname;

    @Column(name="department")
    private String department;

    @Column(name="yearsofexperience")
    private int yearsofexperience;

    @Column(name="qualification")
    private String qualification;

    @Column(name="certification")
    private String certification;

    @Column(name="technicalskills")
    private String technicalskills;
}
