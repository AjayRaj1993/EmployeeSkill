package com.employeeskills;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeSkillApplication {

    public static void main(String[] args) {
        SpringApplication.run(EmployeeSkillApplication.class, args);
    }

}
